package com.natetrystuff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NateTryStuffApplicationTests {

	@Test
	void contextLoads() {
	}

}
